export interface SalesData {
    id: string;
    timestamp: string;
    period: '12:00' | '15:00' | 'final';
    amount: number;
    customers: number;
}

export interface ToDoItem {
    id: string;
    text: string;
    completed: boolean;
    source: 'manual' | 'ai';
}

export interface BestItem {
    name: string;
    sales: number;
}

/**
 * テーブルA：「定時点検表」の1行分を定義
 */
export interface InspectionEntry {
    id: string;
    date: string;         // 日付 (YYYY-MM-DD)
    dayOfWeek: string;    // 曜日
    totalBudget: number;  // 売上予算

    // 12時時点
    actual12: number | null;
    rate12: number | null;
    forecast12: number | null;
    diff12: number | null;
    customers12: number | null;

    // 17時時点
    actual17: number | null;
    rate17: number | null;
    forecast17: number | null;
    diff17: number | null;
    customers17: number | null;

    // 最終計（閉店時）
    actualFinal: number | null;
    budgetRatio: number | null;
    diffFinal: number | null;
    accDiff: number | null;
    customersFinal: number | null;
    accBudgetRatio: number | null;
    accPrevYearRatio: number | null;

    // ロス関連
    lossAmount: number | null;
    lossRate: number | null;

    // 本日の売り込み品
    promotionItem: string;
    promotionTargetSales: number;
    promotionTargetMargin: number;
    promotionActual12Sales: number;
    promotionActual12Rate: number;
    promotionActual17Sales: number;
    promotionActual17Rate: number;

    // 備考・反省
    notes12: string;
    notes17: string;

    // 単品ベスト (野菜・果物)
    bestVegetables: BestItem[];
    bestFruits: BestItem[];
}

/**
 * テーブルB：「売上管理表 野菜・果物」
 */
export interface DailyBudget {
    date: string;
    dayOfWeek: string;
    veggieBudget: number;
    fruitBudget: number;
    totalBudget: number;
}

export interface AppState {
    sales: SalesData[];
    todos: ToDoItem[];
    inspections: InspectionEntry[];
    dailyBudgets: DailyBudget[];
}

export const DATA_VERSION = '2.0.0';
